﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timer : MonoBehaviour
{
  public float timer;
  public Renderer l;

    void Update()
    {
      if (timer > 0) {
        timer -= Time.deltaTime;
      }
      if (timer < 0) {
        l.material.color = Color.red;
      }

    }
}
