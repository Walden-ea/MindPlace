using UnityEngine;
using System.Collections;

public class TimerLesson : MonoBehaviour {

      public int xs, ys;
      public int xm, ym;

      public int timersecond;
      public float secondtime = 0;
      public float secondtimereset = 0;
      public float minetime = 0;
      public float minetimereset = 0;

      void Update () {

        secondtime += Time.deltaTime;
        if (secondtime >= 2.5) {
          timersecond += 1;
        }
        if (secondtime >= 2.5) {
          secondtime = secondtimereset;
        }

        if (timersecond >= 60) {
          minetime += 1;
          timersecond = 0;
        }
        if (minetime >= 60) {
          minetime = minetimereset;
        }
      }

      void OnGUI () {
          GUI.Label(new Rect(Screen.width - xs, ys, 100, 50), " " + timersecond);
          GUI.Label(new Rect(Screen.width - xm, ym, 100, 50), " " + minetime);
      }
}
