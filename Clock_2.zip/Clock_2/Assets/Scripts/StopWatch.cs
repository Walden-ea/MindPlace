using UnityEngine;
using System.Collections;

public class StopWatch : MonoBehaviour {
    public int secondTime; // проверка отчёта секунд в Inspector
    public float minutTime;// проверка отчёта минут в Inspector
    private float timersecond; //(?) - нужно для работы Time.deltaTime

    void Update () {
      timersecond += Time.deltaTime;
      if (timersecond >= 1) {
          secondTime += 1;
          timersecond = 0;
      }
      if (secondTime >= 60) {
          minutTime += 1;
          secondTime = 0;
      }
      if (minutTime >= 60) {
         minutTime = 0;
      }
    }
    void OnGUI () {
      GUI.Label(new Rect(Screen.width - 1000,10,100,50), "SecondTime : " + secondTime );
      GUI.Label(new Rect(Screen.width - 1000, 25, 100, 50), "MinutesTime : " + minutTime);
    }
}
